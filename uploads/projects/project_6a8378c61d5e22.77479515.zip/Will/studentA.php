<?php

include "db.php";

$sql = "INSERT INTO applications(studentID,jobID,projectFile)
VALUES(?,?,?)";

$stmt = $conn->prepare($sql);

$stmt->execute([
    $_POST['studentID'],
    $_POST['jobID'],
    $fileName
]);

echo "Application Submitted";