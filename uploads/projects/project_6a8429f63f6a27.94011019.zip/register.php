
<!DOCTYPE html>
<html>
    <head>
	    <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<title>SignUp</title>
		<link rel="stylesheet" href="style.css"/>
	</head>
	
	<body>
	    <div class="main-container">
		    <form class="form-content">
			    <h2>WIL-CONNECT</h2>
				<p class="header-txt">__UNLOCKING OPPORTUNITIES | BUILDING FUTURES__</p>
				<br/>
				<span id="error" name="error">Error</span>
				
				<div class="input-group">
					<input type="text" name="name" id="name" placeholder=" "/>
					<label for="name">First Name</label>
				</div>
				<div class="input-group">
					<input type="text" name="surname" id="surname" placeholder=" "/>
					<label for="surname">Surname</label>
				</div>
				<div class="input-group">
					<input type="text" name="username" id="username" placeholder=" "/>
					<label for="programme">Student Number</label>
				</div>
				<div class="input-group">
					<input type="text" name="email" id="email" placeholder=" "/>
					<label for="email">Email</label>
				</div>
				<div class="input-group">
					<input type="password" name="password" id="password" placeholder=" "/>
					<label for="password">Password</label>
				</div>
				<div class="input-group">
					<input type="password" name="confirmPassword" id="confirmPassword" placeholder=" "/>
					<label for="confirmPassword">Confirm Password</label>
				</div>
				<div class="input-group">
					<input type="text" name="faculty" id="faculty" placeholder=" "/>
					<label for="faculty">Faculty</label>
				</div>
				<div class="input-group">
					<input type="text" name="programme" id="programme" placeholder=" "/>
					<label for="programme">Programme</label>
				</div>
				<div class="input-group">
					<input type="text" name="studyYear" id="studyYear" placeholder=" "/>
					<label for="studyYear">Year of Study</label>
				</div>
				<button type="submit" name="register" id="register">Register</button>
				<p class="signup-txt">Already have an account? <a href="login.php">Login</a></p>
			</form>
		</div>
		
		<script>
		    
		</script>
	</body>
</html>
